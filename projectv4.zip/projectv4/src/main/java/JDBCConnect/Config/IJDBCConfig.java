/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package JDBCConnect.Config;

/**
 *
 * @author FanciGoD
 */
public interface IJDBCConfig {
    String hostname = "localhost";
    String port = "3306";
    String dbName = "projectv4";
    String username = "root";
    String password = "admin";
}
