package JDBCConnect.model;

import JDBCConnect.Connect.ConnectDTB;
import JDBCConnect.Connect.JDBCConnect;
import entity.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.io.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class DashboardModel {
    public List<? extends Product> getDataProduct() {
        Product product;
        List<Product> productList = new ArrayList<>();
        String sql = "SELECT *, category.Name as cateName, supplier.Name as supName\n" +
                "FROM product \n" +
                "join category on product.Category_ID = category.Category_ID\n" +
                "join supplier on product.Supplier_ID = supplier.Supplier_ID\n" +
                "Where Is_deleted = 0 order by product.Product_ID asc";
        try (Connection connection = ConnectDTB.getJDBCConnect();
             PreparedStatement preparedStatement = connection.prepareStatement(sql);
             ResultSet resultSet = preparedStatement.executeQuery()) {
            while (resultSet.next()) {
                product = new Product();
                product.setProductID(resultSet.getInt("Product_ID"));
                product.setProductName(resultSet.getString("Name"));
                product.setSellPrice((long) resultSet.getDouble("Sell_price"));
                product.setImportPrice((long) resultSet.getDouble("Import_price"));
                product.setQuantity(resultSet.getInt("Quantity"));
                product.setCategory(resultSet.getString("cateName"));
                product.setSupplierName(resultSet.getString("supName"));
                product.setImage(resultSet.getString("Image"));
                productList.add(product);
            }
            if (productList.isEmpty()) {
                return null;
            } else
                return productList;
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    public void deleteProduct(int productId) {
        String sql = "UPDATE `product` SET `Is_deleted` = '1' WHERE (`Product_ID` = ?)";
        try (Connection connection = ConnectDTB.getJDBCConnect();
             PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, productId);
            preparedStatement.execute();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Product getProduct(String name) {
        Product product;
        String sql = "SELECT *, project.category.Name as cateName, project.supplier.Name as supName\n" +
                "FROM project.product \n" +
                "join project.category on product.Category_ID = category.Category_ID\n" +
                "join project.supplier on product.Supplier_ID = supplier.Supplier_ID\n" +
                "Where product.Name = ? and Is_deleted = '0'";
        try (Connection connection = ConnectDTB.getJDBCConnect();
             PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setString(1, name);
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                product = new Product();
                product.setProductID(resultSet.getInt("Product_ID"));
                product.setProductName(resultSet.getString("Name"));
                product.setSellPrice((long) resultSet.getDouble("Sell_price"));
                product.setImportPrice((long) resultSet.getDouble("Import_price"));
                product.setCategory(resultSet.getString("cateName"));
                product.setQuantity(resultSet.getInt("Quantity"));
                product.setSupplierName(resultSet.getString("supName"));
                product.setImage(resultSet.getString("Image"));
                return product;
            }
            return null;
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    public boolean updateProduct(Product product) {
        Category category = getCategory(product.getCategory());
        String sql = "UPDATE `product` SET `Name` = ?, `Sell_price` = ?, `Import_price` = ?, `Category_ID` = ?, `Image` = ? WHERE (`Product_ID` = '22')";
        try (Connection connection = ConnectDTB.getJDBCConnect();
             PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setString(1, product.getProductName());
            preparedStatement.setDouble(2, product.getSellPrice());
            preparedStatement.setDouble(3, product.getImportPrice());
            preparedStatement.setInt(4, category.getCategoryId());
            preparedStatement.setString(5, product.getImage());
            preparedStatement.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean importProduct(int productID, int quantity) {
        String sql = "UPDATE `product` SET `Quantity` = `Quantity` + ? WHERE (`Product_ID` = ?)";
        try (Connection connection = ConnectDTB.getJDBCConnect();
             PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, quantity);
            preparedStatement.setInt(2, productID);
            preparedStatement.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean createProduct(Product product, String path) {
        Category category = getCategory(product.getCategory());
        System.out.println(path);
        String sql = "INSERT INTO `product` (`Name`, `Sell_price`, `Import_price`, `Category_ID`, `Image` ,`Supplier_ID`) VALUES (?, ?, ?, ?, ?,1);";
        try (Connection connection = ConnectDTB.getJDBCConnect();
             PreparedStatement pre = connection.prepareStatement(sql)) {
            pre.setString(1, product.getProductName());
            pre.setDouble(2, product.getSellPrice());
            pre.setDouble(3, product.getImportPrice());
            pre.setInt(4, category.getCategoryId());
            pre.setString(5, path);
            pre.execute();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public void createCategory(String name) {
        String sql = "INSERT INTO `category` (`Name`) VALUES (?)";
        try (Connection connection = ConnectDTB.getJDBCConnect();
             PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setString(1, name);
            preparedStatement.execute();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Category getCategory(String name) {
        Category category;
        String sql = "SELECT * FROM category where `Name` = ?";
        try (Connection connection = ConnectDTB.getJDBCConnect();
             PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setString(1, name);
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                category = new Category(resultSet.getInt("Category_ID"), resultSet.getString("Name"));
                return category;
            } else
                return null;
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }


    public ObservableList<Customer> getDataCustomerList() throws SQLException {
        ObservableList<Customer> CustomerList = FXCollections.observableArrayList();
        String sql = "select * from client where Is_deleted = 0";
        Connection con = JDBCConnect.Connect();
        PreparedStatement ps = con.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        while (rs.next()) {
            int customerID = rs.getInt("Client_ID");
            String customerName = rs.getString("Name");
            String customerAddress = rs.getString("Address");
            String customerPhoneNum = rs.getString("Phone");
            String customerEmail = rs.getString("Email");
            Customer tempCustomer = new Customer(customerID, customerName, customerAddress, customerPhoneNum, customerEmail);
            CustomerList.add(tempCustomer);
        }
        return CustomerList;
    }

    public Customer getDataCustomer(int customerID) throws SQLException {

        String sql = "select * from client where `Client_ID` = ? ";
        Connection con = JDBCConnect.Connect();
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setInt(1, customerID);
        ResultSet rs = ps.executeQuery();
        Customer tempCustomer = null;
        while (rs.next()) {
            String customerName = rs.getString("Name");
            String customerAddress = rs.getString("Address");
            String customerPhoneNum = rs.getString("Phone");
            String customerEmail = rs.getString("Email");
            tempCustomer = new Customer(customerID, customerName, customerAddress, customerPhoneNum, customerEmail);

        }
        return tempCustomer;
    }

    public void updateCustomer(String customerName, String customerAddress, String customerPhoneNum, String customerEmail, int customerID) throws SQLException {
        String sql = "UPDATE `projectv4`.`client` SET `Name` = ?, `Address` = ?, `Phone` = ?, `Email` = ? WHERE (`Client_ID` = ? )";
        Connection con = JDBCConnect.Connect();
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, customerName);
        ps.setString(2, customerAddress);
        ps.setString(3, customerPhoneNum);
        ps.setString(4, customerEmail);
        ps.setInt(5, customerID);
        ps.executeUpdate();


    }

    public void deleteCustomer(int CustomerID) {
        String sql = "update projectv4.Client set Is_deleted = '1' where(`Client_ID` = ?)";
        try (Connection con = JDBCConnect.Connect();
             PreparedStatement ps = con.prepareStatement(sql);) {
            ps.setInt(1, CustomerID);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Supplier> getListSupplier() {
        Supplier supplier;
        List<Supplier> supplierList = new ArrayList<>();
        String sql = "SELECT * FROM supplier";
        try (Connection connection = ConnectDTB.getJDBCConnect();
             PreparedStatement preparedStatement = connection.prepareStatement(sql);
             ResultSet resultSet = preparedStatement.executeQuery()) {
            while (resultSet.next()) {
                supplier = new Supplier();
                supplier.setId(resultSet.getInt("Supplier_ID"));
                supplier.setName(resultSet.getString("Name"));
                supplier.setPhone(resultSet.getString("Phone"));
                supplier.setAddress(resultSet.getString("Address"));
                supplier.setEmail(resultSet.getString("Email"));
                supplierList.add(supplier);
            }
            if (supplierList.isEmpty()) {
                return null;
            } else {
                return supplierList;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    public Supplier getSupplier(String name) {
        String sql = "SELECT * FROM supplier where `Name` = ?";
        try (Connection connection = ConnectDTB.getJDBCConnect();
             PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setString(1, name);
            ResultSet resultSet = preparedStatement.executeQuery();
            Supplier supplier = new Supplier();
            if (resultSet.next()) {
                supplier.setId(resultSet.getInt("Supplier_ID"));
                supplier.setName(resultSet.getString("Name"));
                supplier.setPhone(resultSet.getString("Phone"));
                supplier.setAddress(resultSet.getString("Address"));
                supplier.setEmail(resultSet.getString("Email"));
            }
            return supplier;
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    public boolean importPurchase(int userId, long totalPrice, int supId) {
        Calendar calendar = Calendar.getInstance();
        java.util.Date date1 = calendar.getTime();
        java.sql.Date date = new Date(date1.getTime());
        String sql = "INSERT INTO purchase (`Supplier_ID`, `Account_ID`, `Create_time`, `Total_price`) VALUES (?, ?, ?, ?)";
        try (Connection connection = ConnectDTB.getJDBCConnect();
             PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, supId);
            preparedStatement.setInt(2, userId);
            preparedStatement.setDate(3, date);
            preparedStatement.setDouble(4, totalPrice);
            preparedStatement.execute();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }

    }

    public boolean importPurchaseDetail(int productId, int quantity) {
        DashboardModel dashboardModel = new DashboardModel();
        List<Purchase> purchaseList = dashboardModel.getDataImport();
        Purchase purchase = purchaseList.get(purchaseList.size() - 1);
        String sql = "INSERT INTO `projectv4`.`purchase_detail` (`Purchase_ID`, `Product_ID`, `Quantity`) VALUES (?, ?, ?);";
        try (Connection connection = ConnectDTB.getJDBCConnect();
             PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, purchase.getPurchaseId());
            preparedStatement.setInt(2, productId);
            preparedStatement.setInt(3, quantity);
            preparedStatement.execute();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<Purchase> getDataImport() {
        Purchase purchase;
        String sql = "SELECT *, supplier.Name as supName, account.Name as accountName FROM projectv4.purchase " +
                "join projectv4.supplier on purchase.Supplier_ID = supplier.Supplier_ID " +
                "join projectv4.account on purchase.Account_ID = account.Account_ID";
        try (Connection connection = ConnectDTB.getJDBCConnect();
             PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            ResultSet resultSet = preparedStatement.executeQuery();
            List<Purchase> purchaseList = new ArrayList<>();
            while (resultSet.next()) {
                purchase = new Purchase();
                purchase.setPurchaseId(resultSet.getInt("Purchase_ID"));
                purchase.setSupplierName(resultSet.getString("supName"));
                purchase.setAccountName(resultSet.getString("accountName"));
                purchase.setCreateTime(resultSet.getDate("Create_time"));
                purchase.setTotalPrice((long) resultSet.getDouble("Total_price"));
                purchaseList.add(purchase);
            }
            return purchaseList;

        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    public List<Bill> getDataBill() {
        Bill bill;
        String sql = "SELECT *, client.Name as clientName, account.Name as accountName FROM projectv4.bill " +
                "join projectv4.client on bill.Client_ID = client.Client_ID " +
                "join projectv4.account on bill.Account_ID = account.Account_ID";
        try (Connection connection = ConnectDTB.getJDBCConnect();
             PreparedStatement preparedStatement = connection.prepareStatement(sql);
             ResultSet resultSet = preparedStatement.executeQuery()) {
            List<Bill> billList = new ArrayList<>();
            while (resultSet.next()) {
                bill = new Bill();
                bill.setBillId(resultSet.getInt("Bill_ID"));
                bill.setCustomer(resultSet.getString("clientName"));
                bill.setCreateBy(resultSet.getString("accountName"));
                bill.setTotalPrice((long) resultSet.getDouble("Total_price"));
                bill.setCreateTime(resultSet.getDate("Create_time"));
                billList.add(bill);
            }
            if (billList.isEmpty()) {
                return null;
            }
            return billList;
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    public boolean checkCustomer(String name, String email, String phone) {
        String sql = "SELECT * FROM projectv4.client where Name = ? and Email = ? and Phone = ?";
        try (Connection connection = ConnectDTB.getJDBCConnect();
             PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setString(1, name);
            preparedStatement.setString(2, email);
            preparedStatement.setString(3, phone);
            ResultSet resultSet = preparedStatement.executeQuery();
            return resultSet.next();
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean importBill(int userId, long totalPrice, int customerId) {
        Calendar calendar = Calendar.getInstance();
        java.util.Date date1 = calendar.getTime();
        java.sql.Date date = new Date(date1.getTime());
        String sql = "INSERT INTO `bill` (`Client_ID`, `Account_ID`, `Create_time`, `Total_price`) VALUES (?, ?, ?, ?)";
        try (Connection connection = ConnectDTB.getJDBCConnect();
             PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, customerId);
            preparedStatement.setInt(2, userId);
            preparedStatement.setDate(3, date);
            preparedStatement.setDouble(4, totalPrice);
            preparedStatement.execute();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean importBillDetail(int productId, int quantity) {
        List<Bill> billList = getDataBill();
        Bill bill = billList.get(billList.size() - 1);
        String sql = "INSERT INTO `bill_detail` (`Bill_ID`, `Product_ID`, `Quantity`) VALUES (?, ?, ?);";
        try (Connection connection = ConnectDTB.getJDBCConnect();
             PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, bill.getBillId());
            preparedStatement.setInt(2, productId);
            preparedStatement.setInt(3, quantity);
            preparedStatement.execute();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean exportProduct(int productID, int quantity) {
        String sql = "UPDATE `product` SET `Quantity` = `Quantity` - ? WHERE (`Product_ID` = ?)";
        try (Connection connection = ConnectDTB.getJDBCConnect();
             PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, quantity);
            preparedStatement.setInt(2, productID);
            preparedStatement.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean createCustomer(String name, String email, String phone, String address) {
        String sql = "INSERT INTO `client` (`Name`, `Address`, `Phone`, `Email`) VALUES (?, ?, ?, ?);";
        try (Connection connection = ConnectDTB.getJDBCConnect();
             PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setString(1, name);
            preparedStatement.setString(2, address);
            preparedStatement.setString(3, phone);
            preparedStatement.setString(4, email);
            preparedStatement.execute();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
