package com.controllerfx.projectv4;

import JDBCConnect.model.DashboardModel;
import entity.*;
import entity.GetData;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.security.cert.Extension;
import java.sql.SQLException;
import java.util.*;
import java.util.function.Predicate;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.chart.BarChart;
import javafx.scene.layout.AnchorPane;
import javafx.util.Callback;

public class DashboardController implements Initializable {
    @FXML
    public Button imageBut;
    public TableColumn<Purchase, Integer> colPurchaseHistoryProductID;
    public TableColumn<Purchase, String> colPurchaseHistoryCreatedBy;
    public TableColumn<Purchase, java.sql.Date> colPurchaseHistoryCreateTime;
    public TableColumn<Purchase, String> colPurchaseHistorySupplier;
    public TableColumn<Purchase, Void> colPurchaseHistoryAction;
    public TableColumn<ImportProduct, Integer> colPurchaseProductID;
    public Label totalPricePurchase;
    @FXML
    private AnchorPane InventoryPanel;

    @FXML
    private Label SupplierTotalPrice;

    @FXML
    private AnchorPane addOrderPanel;

    @FXML
    private AnchorPane addPurchasePanel;

    @FXML
    private TableView<ImportProduct> addPurchaseTable;

    @FXML
    private AnchorPane billHistoryPanel;

    @FXML
    private Button btSaveChangeToOrderTable;

    @FXML
    private Button btnAddCustomer;

    @FXML
    private Button btnAddOrder;

    @FXML
    private Button btnAddOrderLeft;

    @FXML
    private Button btnAddProduct;

    @FXML
    private Button btnAddPurchase;

    @FXML
    private Button btnAddPurchaseLeft;

    @FXML
    private Button btnAddSupplier;

    @FXML
    private Button btnAddToOrderTable;

    @FXML
    private Button btnAddToPurchase;

    @FXML
    private Button btnBillHistoryLeft;

    @FXML
    private Button btnCustomerLeft;

    @FXML
    private Button btnHomeLeft;

    @FXML
    private Button btnInventoryLeft;

    @FXML
    private Button btnNewAccountLeft;

    @FXML
    private Button btnPurchaseHistoryLeft;

    @FXML
    private Button btnRemovePurchase;

    @FXML
    private Button btnRemoveToOrderTable;

    @FXML
    private Button btnSaveChangeToPurchase;

    @FXML
    private Button btnStatisticsLeft;

    @FXML
    private Button btnSupplierLeft;

    @FXML
    private Button btnUpdateCustomer;

    @FXML
    private Button btnUpdateProduct;

    @FXML
    private Button btnUpdateSupplier;

    @FXML
    private TextField categoryView;

    @FXML
    private TableColumn<Product, Void> colAction;

    @FXML
    private TableColumn<Bill, Void> colBillAction;

    @FXML
    private TableColumn<?, ?> colBillCreateTime;

    @FXML
    private TableColumn<?, ?> colBillCreatedBy;

    @FXML
    private TableColumn<?, ?> colBillCustomer;

    @FXML
    private TableColumn<?, ?> colBillID;

    @FXML
    private TableColumn<Product, String> colCategory;

    @FXML
    private TableColumn<Customer, Void> colCustomerAction;

    @FXML
    private TableColumn<?, ?> colCustomerAddress;

    @FXML
    private TableColumn<?, ?> colCustomerEmail;

    @FXML
    private TableColumn<?, ?> colCustomerID;

    @FXML
    private TableColumn<?, ?> colCustomerName;

    @FXML
    private TableColumn<?, ?> colCustomerPhoneNumber;

    @FXML
    private TableColumn<Product, Double> colImportPrice;

    @FXML
    private TableColumn<?, ?> colOrderCategory;

    @FXML
    private TableColumn<?, ?> colOrderCategoryView;

    @FXML
    private TableColumn<?, ?> colOrderCreateTime;

    @FXML
    private TableColumn<?, ?> colOrderCreatedBy;

    @FXML
    private TableColumn<?, ?> colOrderFinalPrice;

    @FXML
    private TableColumn<?, ?> colOrderImportPrice;

    @FXML
    private TableColumn<?, ?> colOrderImportView;

    @FXML
    private TableColumn<?, ?> colOrderProductIDView;

    @FXML
    private TableColumn<?, ?> colOrderProductName;

    @FXML
    private TableColumn<?, ?> colOrderProductNameView1;

    @FXML
    private TableColumn<?, ?> colOrderPurchaseID;

    @FXML
    private TableColumn<?, ?> colOrderQuantity;

    @FXML
    private TableColumn<?, ?> colPhoneNumber;

    @FXML
    private TableColumn<Product, String> colProductID;

    @FXML
    private TableColumn<Product, String> colProductName;

    @FXML
    private TableColumn<?, ?> colPurchaseAction;

    @FXML
    private TableColumn<?, ?> colPurchaseCategory;

    @FXML
    private TableColumn<?, ?> colPurchaseCategoryView;

    @FXML
    private TableColumn<?, ?> colPurchaseFinalPrice;

    @FXML
    private TableColumn<?, ?> colPurchaseID;

    @FXML
    private TableColumn<?, ?> colPurchaseImportPrice;

    @FXML
    private TableColumn<?, ?> colPurchaseImportView;

    @FXML
    private TableColumn<Product, Integer> colPurchaseProductIDView;

    @FXML
    private TableColumn<?, ?> colPurchaseProductName;

    @FXML
    private TableColumn<?, ?> colPurchaseProductNameView;

    @FXML
    private TableColumn<?, ?> colPurchaseQuantity;

    @FXML
    private TableColumn<?, ?> colPurchaseSupplier;

    @FXML
    private TableColumn<Product, Integer> colQuantity;

    @FXML
    private TableColumn<Product, Double> colSellPrice;

    @FXML
    private TableColumn<?, ?> colSupplierAction;

    @FXML
    private TableColumn<?, ?> colSupplierAddress;

    @FXML
    private TableColumn<?, ?> colSupplierEmail;

    @FXML
    private TableColumn<?, ?> colSupplierID;

    @FXML
    private TableColumn<?, ?> colSupplierName;

    @FXML
    private TextField customerCustomerAddress;

    @FXML
    private TextField customerCustomerEmail;

    @FXML
    private TextField customerCustomerName;

    @FXML
    private AnchorPane customerPanel;

    @FXML
    private TextField customerPhoneNumber;

    @FXML
    private TextField customerSearch;

    @FXML
    private Label dashboardUsername;

    @FXML
    private BarChart<?, ?> homeChart;

    @FXML
    private AnchorPane homepagePanel;

    @FXML
    private ImageView image;

    @FXML
    private TextField importPriceView;

    @FXML
    private Button logOut;

    @FXML
    private AnchorPane newAccountPanel;

    @FXML
    private TextField newFullName;

    @FXML
    private PasswordField newPassword;

    @FXML
    private PasswordField newRePassword;

    @FXML
    private TextField newUsername;

    @FXML
    private TextField orderAddress;

    @FXML
    private TextField orderCustomerName;

    @FXML
    private TextField orderEmail;

    @FXML
    private TableView<Bill> orderHistoryView;

    @FXML
    private TextField orderPhoneNumber;

    @FXML
    private TableView<OrderProduct> orderTableView;

    @FXML
    private Label orderTotalPrice;

    @FXML
    private TextField productNameView;

    @FXML
    private TableView<Product> productOrderTableView;

    @FXML
    private TextField productSearch;

    @FXML
    private TextField productSearch1;

    @FXML
    private TextField productSearch11;

    @FXML
    private Label productSoldToday;

    @FXML
    private TableView<Product> productTableView;

    @FXML
    private AnchorPane purchaseHistoryPanel;

    @FXML
    private TableView<Purchase> purchaseHistoryView;

    @FXML
    private TableView<Product> purchaseTableView;

    @FXML
    private Label revenueToday;

    @FXML
    private Label revenueToday1;

    @FXML
    private TextField searchOrderHistory;

    @FXML
    private TextField searchPurchaseHistory;

    @FXML
    private ComboBox<String> selectSupplierPurchase;

    @FXML
    private TextField sellPriceView;

    @FXML
    private AnchorPane statisticsPanel;

    @FXML
    private Label supplierAddressPurchase;

    @FXML
    private Label supplierEmailPurchase;

    @FXML
    private AnchorPane supplierPanel;

    @FXML
    private Label supplierPhonePurchase;

    @FXML
    private TextField supplierSearch;

    @FXML
    private TextField supplierSupplierAddress;

    @FXML
    private TextField supplierSupplierEmail;

    @FXML
    private TextField supplierSupplierName;

    @FXML
    private TextField supplierSupplierPhoneNumber;

    @FXML
    private TableView<Customer> customerTable;

    DashboardModel dashboardModel;

    ObservableList<Product> productObservableList = FXCollections.observableArrayList();
    ObservableList<ImportProduct> importProductObservableList = FXCollections.observableArrayList();

    ObservableList<Purchase> purchaseObservableList = FXCollections.observableArrayList();
    ObservableList<Bill> billObservableList = FXCollections.observableArrayList();
    ObservableList<OrderProduct> orderProductObservableList = FXCollections.observableArrayList();
    private File selectedFile;


    public void logOut() {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setHeaderText(null);
        alert.setTitle("Log out");
        alert.setContentText("Are you sure?");
        Optional<ButtonType> option = alert.showAndWait();
        if (option.get().equals(ButtonType.OK)) {
            logOut.getScene().getWindow().hide();
            try {
                Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("Login.fxml")));
                Stage stage = new Stage();
                Scene scene = new Scene(root);
                stage.setScene(scene);
                stage.show();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
    }

    public void switchForm(ActionEvent e) {
        if (e.getSource() == btnHomeLeft) {
            homepagePanel.setVisible(true);
            InventoryPanel.setVisible(false);
            addPurchasePanel.setVisible(false);
            purchaseHistoryPanel.setVisible(false);
            addOrderPanel.setVisible(false);
            billHistoryPanel.setVisible(false);
            customerPanel.setVisible(false);
            supplierPanel.setVisible(false);
            statisticsPanel.setVisible(false);
            newAccountPanel.setVisible(false);

            btnHomeLeft.setStyle("-fx-background-color: #e7525e");
            btnInventoryLeft.setStyle("-fx-background-color: #fbeaeb");
            btnAddPurchaseLeft.setStyle("-fx-background-color: #fbeaeb");
            btnPurchaseHistoryLeft.setStyle("-fx-background-color: #fbeaeb");
            btnAddOrderLeft.setStyle("-fx-background-color: #fbeaeb");
            btnBillHistoryLeft.setStyle("-fx-background-color: #fbeaeb");
            btnCustomerLeft.setStyle("-fx-background-color: #fbeaeb");
            btnSupplierLeft.setStyle("-fx-background-color: #fbeaeb");
            btnStatisticsLeft.setStyle("-fx-background-color: #fbeaeb");
            btnNewAccountLeft.setStyle("-fx-background-color: #fbeaeb");
        } else if (e.getSource() == btnInventoryLeft) {
            homepagePanel.setVisible(false);
            InventoryPanel.setVisible(true);
            addPurchasePanel.setVisible(false);
            purchaseHistoryPanel.setVisible(false);
            addOrderPanel.setVisible(false);
            billHistoryPanel.setVisible(false);
            customerPanel.setVisible(false);
            supplierPanel.setVisible(false);
            statisticsPanel.setVisible(false);
            newAccountPanel.setVisible(false);

            btnHomeLeft.setStyle("-fx-background-color: #fbeaeb");
            btnInventoryLeft.setStyle("-fx-background-color: #e7525e");
            btnAddPurchaseLeft.setStyle("-fx-background-color: #fbeaeb");
            btnPurchaseHistoryLeft.setStyle("-fx-background-color: #fbeaeb");
            btnAddOrderLeft.setStyle("-fx-background-color: #fbeaeb");
            btnBillHistoryLeft.setStyle("-fx-background-color: #fbeaeb");
            btnCustomerLeft.setStyle("-fx-background-color: #fbeaeb");
            btnSupplierLeft.setStyle("-fx-background-color: #fbeaeb");
            btnStatisticsLeft.setStyle("-fx-background-color: #fbeaeb");
            btnNewAccountLeft.setStyle("-fx-background-color: #fbeaeb");

            setTextViewEmpty();
            imageBut.setVisible(true);
            image.setImage(null);
            btnUpdateProduct.setVisible(true);
            btnAddProduct.setVisible(true);
        } else if (e.getSource() == btnAddPurchaseLeft) {
            homepagePanel.setVisible(false);
            InventoryPanel.setVisible(false);
            addPurchasePanel.setVisible(true);
            purchaseHistoryPanel.setVisible(false);
            addOrderPanel.setVisible(false);
            billHistoryPanel.setVisible(false);
            customerPanel.setVisible(false);
            supplierPanel.setVisible(false);
            statisticsPanel.setVisible(false);
            newAccountPanel.setVisible(false);

            btnHomeLeft.setStyle("-fx-background-color: #fbeaeb");
            btnInventoryLeft.setStyle("-fx-background-color: #fbeaeb");
            btnAddPurchaseLeft.setStyle("-fx-background-color: #e7525e");
            btnPurchaseHistoryLeft.setStyle("-fx-background-color: #fbeaeb");
            btnAddOrderLeft.setStyle("-fx-background-color: #fbeaeb");
            btnBillHistoryLeft.setStyle("-fx-background-color: #fbeaeb");
            btnCustomerLeft.setStyle("-fx-background-color: #fbeaeb");
            btnSupplierLeft.setStyle("-fx-background-color: #fbeaeb");
            btnStatisticsLeft.setStyle("-fx-background-color: #fbeaeb");
            btnNewAccountLeft.setStyle("-fx-background-color: #fbeaeb");
        } else if (e.getSource() == btnPurchaseHistoryLeft) {
            homepagePanel.setVisible(false);
            InventoryPanel.setVisible(false);
            addPurchasePanel.setVisible(false);
            purchaseHistoryPanel.setVisible(true);
            addOrderPanel.setVisible(false);
            billHistoryPanel.setVisible(false);
            customerPanel.setVisible(false);
            supplierPanel.setVisible(false);
            statisticsPanel.setVisible(false);
            newAccountPanel.setVisible(false);

            btnHomeLeft.setStyle("-fx-background-color: #fbeaeb");
            btnInventoryLeft.setStyle("-fx-background-color: #fbeaeb");
            btnAddPurchaseLeft.setStyle("-fx-background-color: #fbeaeb");
            btnPurchaseHistoryLeft.setStyle("-fx-background-color: #e7525e");
            btnAddOrderLeft.setStyle("-fx-background-color: #fbeaeb");
            btnBillHistoryLeft.setStyle("-fx-background-color: #fbeaeb");
            btnCustomerLeft.setStyle("-fx-background-color: #fbeaeb");
            btnSupplierLeft.setStyle("-fx-background-color: #fbeaeb");
            btnStatisticsLeft.setStyle("-fx-background-color: #fbeaeb");
            btnNewAccountLeft.setStyle("-fx-background-color: #fbeaeb");
        } else if (e.getSource() == btnAddOrderLeft) {
            homepagePanel.setVisible(false);
            InventoryPanel.setVisible(false);
            addPurchasePanel.setVisible(false);
            purchaseHistoryPanel.setVisible(false);
            addOrderPanel.setVisible(true);
            billHistoryPanel.setVisible(false);
            customerPanel.setVisible(false);
            supplierPanel.setVisible(false);
            statisticsPanel.setVisible(false);
            newAccountPanel.setVisible(false);

            btnHomeLeft.setStyle("-fx-background-color: #fbeaeb");
            btnInventoryLeft.setStyle("-fx-background-color: #fbeaeb");
            btnAddPurchaseLeft.setStyle("-fx-background-color: #fbeaeb");
            btnPurchaseHistoryLeft.setStyle("-fx-background-color: #fbeaeb");
            btnAddOrderLeft.setStyle("-fx-background-color: #e7525e");
            btnBillHistoryLeft.setStyle("-fx-background-color: #fbeaeb");
            btnCustomerLeft.setStyle("-fx-background-color: #fbeaeb");
            btnSupplierLeft.setStyle("-fx-background-color: #fbeaeb");
            btnStatisticsLeft.setStyle("-fx-background-color: #fbeaeb");
            btnNewAccountLeft.setStyle("-fx-background-color: #fbeaeb");
        } else if (e.getSource() == btnBillHistoryLeft) {
            homepagePanel.setVisible(false);
            InventoryPanel.setVisible(false);
            addPurchasePanel.setVisible(false);
            purchaseHistoryPanel.setVisible(false);
            addOrderPanel.setVisible(false);
            billHistoryPanel.setVisible(true);
            customerPanel.setVisible(false);
            supplierPanel.setVisible(false);
            statisticsPanel.setVisible(false);
            newAccountPanel.setVisible(false);

            btnHomeLeft.setStyle("-fx-background-color: #fbeaeb");
            btnInventoryLeft.setStyle("-fx-background-color: #fbeaeb");
            btnAddPurchaseLeft.setStyle("-fx-background-color: #fbeaeb");
            btnPurchaseHistoryLeft.setStyle("-fx-background-color: #fbeaeb");
            btnAddOrderLeft.setStyle("-fx-background-color: #fbeaeb");
            btnBillHistoryLeft.setStyle("-fx-background-color: #e7525e");
            btnCustomerLeft.setStyle("-fx-background-color: #fbeaeb");
            btnSupplierLeft.setStyle("-fx-background-color: #fbeaeb");
            btnStatisticsLeft.setStyle("-fx-background-color: #fbeaeb");
            btnNewAccountLeft.setStyle("-fx-background-color: #fbeaeb");
        } else if (e.getSource() == btnCustomerLeft) {
            homepagePanel.setVisible(false);
            InventoryPanel.setVisible(false);
            addPurchasePanel.setVisible(false);
            purchaseHistoryPanel.setVisible(false);
            addOrderPanel.setVisible(false);
            billHistoryPanel.setVisible(false);
            customerPanel.setVisible(true);
            supplierPanel.setVisible(false);
            statisticsPanel.setVisible(false);
            newAccountPanel.setVisible(false);

            btnHomeLeft.setStyle("-fx-background-color: #fbeaeb");
            btnInventoryLeft.setStyle("-fx-background-color: #fbeaeb");
            btnAddPurchaseLeft.setStyle("-fx-background-color: #fbeaeb");
            btnPurchaseHistoryLeft.setStyle("-fx-background-color: #fbeaeb");
            btnAddOrderLeft.setStyle("-fx-background-color: #fbeaeb");
            btnBillHistoryLeft.setStyle("-fx-background-color: #fbeaeb");
            btnCustomerLeft.setStyle("-fx-background-color: #e7525e");
            btnSupplierLeft.setStyle("-fx-background-color: #fbeaeb");
            btnStatisticsLeft.setStyle("-fx-background-color: #fbeaeb");
            btnNewAccountLeft.setStyle("-fx-background-color: #fbeaeb");
        } else if (e.getSource() == btnSupplierLeft) {
            homepagePanel.setVisible(false);
            InventoryPanel.setVisible(false);
            addPurchasePanel.setVisible(false);
            purchaseHistoryPanel.setVisible(false);
            addOrderPanel.setVisible(false);
            billHistoryPanel.setVisible(false);
            customerPanel.setVisible(false);
            supplierPanel.setVisible(true);
            statisticsPanel.setVisible(false);
            newAccountPanel.setVisible(false);

            btnHomeLeft.setStyle("-fx-background-color: #fbeaeb");
            btnInventoryLeft.setStyle("-fx-background-color: #fbeaeb");
            btnAddPurchaseLeft.setStyle("-fx-background-color: #fbeaeb");
            btnPurchaseHistoryLeft.setStyle("-fx-background-color: #fbeaeb");
            btnAddOrderLeft.setStyle("-fx-background-color: #fbeaeb");
            btnBillHistoryLeft.setStyle("-fx-background-color: #fbeaeb");
            btnCustomerLeft.setStyle("-fx-background-color: #fbeaeb");
            btnSupplierLeft.setStyle("-fx-background-color: #e7525e");
            btnStatisticsLeft.setStyle("-fx-background-color: #fbeaeb");
            btnNewAccountLeft.setStyle("-fx-background-color: #fbeaeb");
        } else if (e.getSource() == btnStatisticsLeft) {
            homepagePanel.setVisible(false);
            InventoryPanel.setVisible(false);
            addPurchasePanel.setVisible(false);
            purchaseHistoryPanel.setVisible(false);
            addOrderPanel.setVisible(false);
            billHistoryPanel.setVisible(false);
            customerPanel.setVisible(false);
            supplierPanel.setVisible(false);
            statisticsPanel.setVisible(true);
            newAccountPanel.setVisible(false);

            btnHomeLeft.setStyle("-fx-background-color: #fbeaeb");
            btnInventoryLeft.setStyle("-fx-background-color: #fbeaeb");
            btnAddPurchaseLeft.setStyle("-fx-background-color: #fbeaeb");
            btnPurchaseHistoryLeft.setStyle("-fx-background-color: #fbeaeb");
            btnAddOrderLeft.setStyle("-fx-background-color: #fbeaeb");
            btnBillHistoryLeft.setStyle("-fx-background-color: #fbeaeb");
            btnCustomerLeft.setStyle("-fx-background-color: #fbeaeb");
            btnSupplierLeft.setStyle("-fx-background-color: #fbeaeb");
            btnStatisticsLeft.setStyle("-fx-background-color: #e7525e");
            btnNewAccountLeft.setStyle("-fx-background-color: #fbeaeb");
        } else if (e.getSource() == btnNewAccountLeft) {
            homepagePanel.setVisible(false);
            InventoryPanel.setVisible(false);
            addPurchasePanel.setVisible(false);
            purchaseHistoryPanel.setVisible(false);
            addOrderPanel.setVisible(false);
            billHistoryPanel.setVisible(false);
            customerPanel.setVisible(false);
            supplierPanel.setVisible(false);
            statisticsPanel.setVisible(false);
            newAccountPanel.setVisible(true);

            btnHomeLeft.setStyle("-fx-background-color: #fbeaeb");
            btnInventoryLeft.setStyle("-fx-background-color: #fbeaeb");
            btnAddPurchaseLeft.setStyle("-fx-background-color: #fbeaeb");
            btnPurchaseHistoryLeft.setStyle("-fx-background-color: #fbeaeb");
            btnAddOrderLeft.setStyle("-fx-background-color: #fbeaeb");
            btnBillHistoryLeft.setStyle("-fx-background-color: #fbeaeb");
            btnCustomerLeft.setStyle("-fx-background-color: #fbeaeb");
            btnSupplierLeft.setStyle("-fx-background-color: #fbeaeb");
            btnStatisticsLeft.setStyle("-fx-background-color: #fbeaeb");
            btnNewAccountLeft.setStyle("-fx-background-color: #e7525e");
        }
    }

    private void getDataForTbProduct() {
        dashboardModel = new DashboardModel();
        productObservableList.addAll(dashboardModel.getDataProduct());
    }


    public void showProductList() {
        getDataForTbProduct();
        if (productObservableList.isEmpty()) {
            productTableView.setItems(null);
        } else {
            colProductID.setCellValueFactory(new PropertyValueFactory<>("productID"));
            colProductName.setCellValueFactory(new PropertyValueFactory<>("productName"));
            colSellPrice.setCellValueFactory(new PropertyValueFactory<>("sellPrice"));
            colImportPrice.setCellValueFactory(new PropertyValueFactory<>("importPrice"));
            colQuantity.setCellValueFactory(new PropertyValueFactory<>("quantity"));
            colCategory.setCellValueFactory(new PropertyValueFactory<>("category"));
            colAction.setCellFactory(param -> new TableCell<Product, Void>() {
                private final Button editButton = new Button("update");
                private final Button deleteButton = new Button("delete");
                private final HBox pane = new HBox(deleteButton, editButton);

                {
                    dashboardModel = new DashboardModel();
                    deleteButton.setOnAction(event -> {
                        Product getProduct = getTableView().getItems().get(getIndex());
                        System.out.println(getProduct.getProductID() + "   " + getProduct.getProductName());
                        dashboardModel.deleteProduct(getProduct.getProductID());
                        productTableView.getItems().remove(getProduct);
                        productTableView.refresh();
                        imageBut.setVisible(true);
                        setTextViewEmpty();
                        image.setImage(null);
                    });

                    editButton.setOnAction(event -> {
                        Product getProduct = getTableView().getItems().get(getIndex());
                        System.out.println(getProduct.getProductID() + "   " + getProduct.getProductName());
                        setTextView(getProduct);
                        imageBut.setVisible(true);
                        btnUpdateProduct.setVisible(true);
                    });
                }

                @Override
                protected void updateItem(Void item, boolean empty) {
                    super.updateItem(item, empty);
                    deleteButton.setStyle(
                            "-fx-background-color: #f19c9d;" +
                                    "-fx-cursor: hand;"
                    );
                    editButton.setStyle(
                            "-fx-background-color: #f19c9d;" +
                                    "-fx-cursor: hand;"

                    );
                    HBox.setMargin(deleteButton, new Insets(2, 20, 0, 30));
                    HBox.setMargin(editButton, new Insets(2, 20, 0, 2));
                    pane.setStyle(
                            ".button {" +
                                    "-fx-background-color: black;" +
                                    "-fx-alignment: center;" +
                                    "}"
                    );
                    setGraphic(empty ? null : pane);
                }
            });

            productTableView.setItems(productObservableList);
        }
    }


    private void searchFilter() {
        FilteredList<Product> filterSearch = new FilteredList<>(productObservableList, e -> true);
        productSearch.setOnKeyReleased(e -> {


            productSearch.textProperty().addListener((observable, oldValue, newValue) -> {
                filterSearch.setPredicate((Predicate<? super Product>) cust -> {
                    if (newValue == null) {
                        return true;
                    }
                    String toLowerCaseFilter = newValue.toLowerCase();
                    if (cust.getProductName().toLowerCase().contains(toLowerCaseFilter)) {
                        return true;
                    } else if (cust.getCategory().toLowerCase().contains(toLowerCaseFilter)) {
                        return true;
                    } else if (newValue.matches("-?\\d+(\\.\\d+)?")) {
                        if (cust.getSellPrice() == Double.parseDouble(newValue)) {
                            return true;
                        } else if (cust.getImportPrice() == Double.parseDouble(newValue)) {
                            return true;
                        }
                    }
                    return false;
                });
            });

            SortedList<Product> products = new SortedList<>(filterSearch);
            products.comparatorProperty().bind(productTableView.comparatorProperty());
            productTableView.setItems(products);
        });
    }

    private void setTextView(Product productSelected) {
        productNameView.setText(productSelected.getProductName());
        sellPriceView.setText(String.valueOf(productSelected.getSellPrice()));
        categoryView.setText(productSelected.getCategory());
        importPriceView.setText(String.valueOf(productSelected.getImportPrice()));
    }

    private void setTextViewEmpty() {
        productNameView.setText(null);
        sellPriceView.setText(null);
        categoryView.setText(null);
        importPriceView.setText(null);
    }

    public void selectProductID() {
        btnAddProduct.setVisible(false);
        btnUpdateProduct.setVisible(false);
        productTableView.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<Product>() {
            @Override
            public void changed(ObservableValue<? extends Product> observableValue, Product product, Product newProduct) {
                GetData.getProductID = newProduct.getProductID();
                setTextView(newProduct);
                imageBut.setVisible(false);
                if (newProduct.getImage() != null) {
                    File imageFile = new File(newProduct.getImage());
                    Image openImage = null;
                    try {
                        openImage = new Image(imageFile.getAbsolutePath());
                        image.setImage(openImage);
                    } catch (Exception e) {
                        e.printStackTrace();
                        image.setImage(null);
                    }
                } else {
                    image.setImage(null);
                }
            }
        });

    }

    public void updateProduct() {
        dashboardModel = new DashboardModel();
        if (productNameView.getText().isEmpty() || categoryView.getText().isEmpty() || sellPriceView.getText().isEmpty()
                || importPriceView.getText().isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("ERROR!!!!");
            alert.setContentText("Your field is empty");
            alert.setHeaderText(null);
            alert.show();
        } else {
            Product product = new Product();
            product.setProductName(productNameView.getText());
            product.setSellPrice(Long.parseLong(sellPriceView.getText()));
            product.setImportPrice(Long.parseLong(importPriceView.getText()));
            product.setCategory(categoryView.getText());
            product.setImage(image.getImage().getUrl());
            ObservableList<Product> tempTable = FXCollections.observableArrayList();
            if (dashboardModel.getCategory(categoryView.getText()) == null) {
                dashboardModel.createCategory(categoryView.getText());
                updateProductInDtb(product);
                tempTable.addAll(dashboardModel.getDataProduct());
                productTableView.setItems(tempTable);
            } else {
                updateProductInDtb(product);
                tempTable.addAll(dashboardModel.getDataProduct());
                productTableView.setItems(tempTable);
            }
        }
    }

    private void updateProductInDtb(Product product) {
        if (selectedFile != null) {
            String uri = "src/main/resources/image/" + selectedFile.getName();
            GetData.path = uri;
            try {
                Files.copy(selectedFile.toPath(), Paths.get(uri), StandardCopyOption.REPLACE_EXISTING);
            } catch (IOException e) {
                e.printStackTrace();
            }
            product.setImage(uri);
        }
        if (dashboardModel.updateProduct(product)) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setHeaderText(null);
            alert.setTitle("INFORMATION!!");
            alert.setContentText("Update successful");
            alert.show();
        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("ERROR!!!!");
            alert.setContentText("Something Wrong");
            alert.setHeaderText(null);
            alert.show();
        }
    }


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        showProductList();
        searchFilter();
        try {
            showCustomerList();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        showPurchaseTbView();
        showProductImportList();
        getDataForComboboxSup();
        selectSupplierPurchase.setOnAction(this::getSupplierInfor);
        showPurchaseList();
        showBillList();
        showProductOrderView();
        showOrderTable();
    }

    public void addProductToTbOrder(ActionEvent event) {
        orderTableView.refresh();
        orderTableView.setItems(orderProductObservableList);
        ObservableList<OrderProduct> tempTable = orderTableView.getItems();
        Long total = 0L;
        for (OrderProduct x : tempTable) {
            if (!x.getOrderQuantity().getText().isEmpty()) {
                orderTableView.setItems(tempTable);
                orderTableView.refresh();
                total += x.getTotalPriceOrder();
            }
        }
        orderTotalPrice.setText(String.valueOf(total));
    }
    private void showProductOrderView() {
        colOrderProductIDView.setCellValueFactory(new PropertyValueFactory<>("productID"));
        colOrderProductNameView1.setCellValueFactory(new PropertyValueFactory<>("productName"));
        colOrderImportView.setCellValueFactory(new PropertyValueFactory<>("sellPrice"));
        colOrderCategoryView.setCellValueFactory(new PropertyValueFactory<>("category"));
        productOrderTableView.setItems(productObservableList);
    }
    private void showOrderTable() {
        colOrderPurchaseID.setCellValueFactory(new PropertyValueFactory<>("productID"));
        colOrderProductName.setCellValueFactory(new PropertyValueFactory<>("productName"));
        colOrderImportPrice.setCellValueFactory(new PropertyValueFactory<>("sellPrice"));
        colOrderQuantity.setCellValueFactory(new PropertyValueFactory<>("orderQuantity"));
        colOrderCategory.setCellValueFactory(new PropertyValueFactory<>("category"));
        colOrderFinalPrice.setCellValueFactory(new PropertyValueFactory<>("totalPriceOrder"));
        orderTableView.setItems(null);
    }

    private void showBillList() {
        getDataForBillHistory();
        if (billObservableList.isEmpty()) {
            orderHistoryView.setItems(null);
        } else {
            colBillID.setCellValueFactory(new PropertyValueFactory<>("billId"));
            colBillCreatedBy.setCellValueFactory(new PropertyValueFactory<>("createBy"));
            colBillCreateTime.setCellValueFactory(new PropertyValueFactory<>("createTime"));
            colBillCustomer.setCellValueFactory(new PropertyValueFactory<>("customer"));
            colBillAction.setCellFactory(param -> new TableCell<Bill, Void>() {
                private final Button viewBillButton = new Button("view");

                {
                    dashboardModel = new DashboardModel();
                    viewBillButton.setOnAction(event -> {
                        Bill getBill = getTableView().getItems().get(getIndex());
                        System.out.println(getBill.getBillId());
                    });
                }

                @Override
                protected void updateItem(Void item, boolean empty) {
                    super.updateItem(item, empty);
                    if (empty) {
                        return;
                    } else {
                        setGraphic(viewBillButton);
                    }
                }
            });
            orderHistoryView.setItems(billObservableList);
        }
    }
    private void getDataForBillHistory() {
        dashboardModel = new DashboardModel();
        List<Bill> bills = dashboardModel.getDataBill();
        if (bills != null) {
            billObservableList.addAll(bills);
        }
    }

    private void showPurchaseList() {
        getDataForPurchaseHistory();
        if (purchaseObservableList.isEmpty()) {
            purchaseHistoryView.setItems(null);
        } else {
            colPurchaseHistoryProductID.setCellValueFactory(new PropertyValueFactory<>("purchaseId"));
            colPurchaseHistorySupplier.setCellValueFactory(new PropertyValueFactory<>("supplierName"));
            colPurchaseHistoryCreatedBy.setCellValueFactory(new PropertyValueFactory<>("accountName"));
            colPurchaseHistoryCreateTime.setCellValueFactory(new PropertyValueFactory<>("createTime"));
            colPurchaseHistoryAction.setCellFactory(param -> new TableCell<Purchase, Void>() {
                private final Button viewBillButton = new Button("view");

                {
                    dashboardModel = new DashboardModel();
                    viewBillButton.setOnAction(event -> {
                        Purchase getPurchase = getTableView().getItems().get(getIndex());
                        System.out.println(getPurchase.getPurchaseId());
                    });
                }

                @Override
                protected void updateItem(Void item, boolean empty) {
                    super.updateItem(item, empty);
                    if (empty) {
                        return;
                    } else {
                        setGraphic(viewBillButton);
                    }
                }
            });
            purchaseHistoryView.setItems(purchaseObservableList);
        }
    }

    private void getDataForPurchaseHistory() {
        dashboardModel = new DashboardModel();
        purchaseObservableList.addAll(dashboardModel.getDataImport());
    }
    private void getDataForComboboxSup() {
        dashboardModel = new DashboardModel();
        List<String> nameList = new ArrayList<>();
        for (Supplier x : dashboardModel.getListSupplier()) {
            nameList.add(x.getName());
        }
        selectSupplierPurchase.getItems().addAll(nameList);
    }

    public void getSupplierInfor(ActionEvent event) {
        String supName = selectSupplierPurchase.getValue();
        System.out.println(supName);
        dashboardModel = new DashboardModel();
        Supplier supplier = dashboardModel.getSupplier(supName);
        GetData.getSupplierID = supplier.getId();
        supplierAddressPurchase.setText(supplier.getAddress());
        supplierPhonePurchase.setText(supplier.getPhone());
        supplierEmailPurchase.setText(supplier.getEmail());
    }

    public void chooseImage(ActionEvent event) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.gif", "*.jpeg", "*.tiff")
        );
        selectedFile = fileChooser.showOpenDialog(imageBut.getScene().getWindow());
        if (selectedFile != null) {
            Image tempImage = new Image(selectedFile.toURI().toString());
            image.setImage(tempImage);
        }
    }


    public void addProduct(ActionEvent event) {
        dashboardModel = new DashboardModel();
        if (productNameView.getText().isEmpty() || categoryView.getText().isEmpty() || sellPriceView.getText().isEmpty()
                || importPriceView.getText().isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("ERROR!!!!");
            alert.setContentText("Your field is empty");
            alert.setHeaderText(null);
            alert.show();
        } else {
            Product product = new Product();
            product.setProductName(productNameView.getText());
            product.setSellPrice(Long.parseLong(sellPriceView.getText()));
            product.setImportPrice(Long.parseLong(importPriceView.getText()));
            product.setCategory(categoryView.getText());
            ObservableList<Product> tempTable = productTableView.getItems();
            if (dashboardModel.getCategory(categoryView.getText()) == null) {
                dashboardModel.createCategory(categoryView.getText());
                insertToDtbProduct(product);
                tempTable.add(product);
                productTableView.setItems(tempTable);
            } else {
                insertToDtbProduct(product);
                tempTable.add(product);
                productTableView.setItems(tempTable);
            }
        }

    }

    private void insertToDtbProduct(Product product) {
        String uri = "src/main/resources/image/" + selectedFile.getName();
        GetData.path = uri;
        try {
            Files.copy(selectedFile.toPath(), Paths.get(uri), StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) {
            e.printStackTrace();
        }
        if (dashboardModel.createProduct(product, uri)) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setHeaderText(null);
            alert.setTitle("INFORMATION!!");
            alert.setContentText("Create successful");
            alert.show();
        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("ERROR!!!!");
            alert.setContentText("Something Wrong");
            alert.setHeaderText(null);
            alert.show();
        }
    }

    public void showCustomerList() throws SQLException {
        DashboardModel dm = new DashboardModel();
        ObservableList<Customer> CustomerList = dm.getDataCustomerList();
        colCustomerID.setCellValueFactory(new PropertyValueFactory<>("customerID"));
        colCustomerName.setCellValueFactory(new PropertyValueFactory<>("customerName"));
        colCustomerAddress.setCellValueFactory(new PropertyValueFactory<>("customerAddress"));
        colCustomerPhoneNumber.setCellValueFactory(new PropertyValueFactory<>("customerPhoneNum"));
        colCustomerEmail.setCellValueFactory(new PropertyValueFactory<>("customerEmail"));
        colCustomerAction.setCellFactory(param -> new TableCell<Customer, Void>() {
            private final Button deleteCustomerButton = new Button("delete");

            {
                dashboardModel = new DashboardModel();
                deleteCustomerButton.setOnAction(event -> {
                    Customer getCustomer = getTableView().getItems().get(getIndex());
                    System.out.println(getCustomer.getCustomerID() + "   " + getCustomer.getCustomerName());
                    dashboardModel.deleteCustomer(getCustomer.getCustomerID());
                    customerTable.getItems().remove(getCustomer);
                    customerTable.refresh();
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    return;
                } else {
                    setGraphic(deleteCustomerButton);
                }
            }

        });
        customerTable.setItems(CustomerList);
    }

    public void updateCustomerID() throws SQLException {
        DashboardModel dm = new DashboardModel();
        String regexPattern = "^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$";

        if (customerCustomerName.getText().isEmpty() || customerCustomerAddress.getText().isEmpty() || customerPhoneNumber.getText().isEmpty() || customerCustomerEmail.getText().isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("ERROR!!!!");
            alert.setContentText("fill the blank....");
            alert.setHeaderText(null);
            alert.show();
        } else {
            if (customerCustomerEmail.getText().matches(regexPattern)) {
                dm.updateCustomer(customerCustomerName.getText(), customerCustomerAddress.getText(), customerPhoneNumber.getText(), customerCustomerEmail.getText(), GetData.getCustomerID);
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setHeaderText(null);
                alert.setTitle("Update customer");
                alert.setContentText("Updated successfully");
                alert.showAndWait();
            } else {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("ERROR!!!!");
                alert.setContentText("Check email again");
                alert.setHeaderText(null);
                alert.show();
            }
        }
    }

    public void selectCustomerID() throws SQLException {
        Customer selectCustomer = customerTable.getSelectionModel().getSelectedItem();
        GetData.getCustomerID = selectCustomer.getCustomerID();
        DashboardModel dm = new DashboardModel();
        Customer customer = dm.getDataCustomer(GetData.getCustomerID);
        customerCustomerName.setText(customer.getCustomerName());
        customerCustomerAddress.setText(customer.getCustomerAddress());
        customerPhoneNumber.setText(customer.getCustomerPhoneNum());
        customerCustomerEmail.setText(customer.getCustomerEmail());

    }

    private void showPurchaseTbView() {
        colPurchaseProductIDView.setCellValueFactory(new PropertyValueFactory<>("productID"));
        colPurchaseProductNameView.setCellValueFactory(new PropertyValueFactory<>("productName"));
        colPurchaseImportView.setCellValueFactory(new PropertyValueFactory<>("importPrice"));
        colPurchaseCategoryView.setCellValueFactory(new PropertyValueFactory<>("category"));
        purchaseTableView.setItems(productObservableList);
    }

    private void showProductImportList() {
        colPurchaseProductID.setCellValueFactory(new PropertyValueFactory<>("productID"));
        colPurchaseProductName.setCellValueFactory(new PropertyValueFactory<>("productName"));
        colPurchaseImportPrice.setCellValueFactory(new PropertyValueFactory<>("importPrice"));
        colPurchaseQuantity.setCellValueFactory(new PropertyValueFactory<>("quantityImport"));
        colPurchaseCategory.setCellValueFactory(new PropertyValueFactory<>("category"));
        colPurchaseFinalPrice.setCellValueFactory(new PropertyValueFactory<>("totalPriceImport"));
        addPurchaseTable.setItems(null);
    }


    public void addPurchase(ActionEvent event) {
        dashboardModel = new DashboardModel();
        if (importProductObservableList.isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("ERROR!!!!");
            alert.setContentText("check your import product table");
            alert.setHeaderText(null);
            alert.show();
        }  else {
            dashboardModel.importPurchase(GetData.userId, Long.parseLong(totalPricePurchase.getText()), GetData.getSupplierID);
            for (ImportProduct x : importProductObservableList) {
                dashboardModel.importPurchaseDetail(x.getProductID(), Integer.parseInt(x.getQuantityImport().getText()));
                dashboardModel.importProduct(x.getProductID(), Integer.parseInt(x.getQuantityImport().getText()));
            }
            ObservableList<Product> tempTable = FXCollections.observableArrayList();
            tempTable.addAll(dashboardModel.getDataProduct());
            productTableView.setItems(tempTable);
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setHeaderText(null);
            alert.setTitle("Update customer");
            alert.setContentText("Updated successfully");
            alert.showAndWait();
        }
    }

    public void addProductToTbPurchase(ActionEvent event) {
        addPurchaseTable.refresh();
        addPurchaseTable.setItems(importProductObservableList);
        ObservableList<ImportProduct> tempTable = addPurchaseTable.getItems();
        Long total = 0L;
        for (ImportProduct x : tempTable) {
            if (!x.getQuantityImport().getText().isEmpty()) {
                addPurchaseTable.setItems(tempTable);
                addPurchaseTable.refresh();
                total += x.getTotalPriceImport();
            }
        }
        totalPricePurchase.setText(String.valueOf(total));
    }

    public void saveChangeTbPurchase(ActionEvent event) {
        ObservableList<ImportProduct> tempTable = addPurchaseTable.getItems();
        Long total = 0L;
        for (ImportProduct x : tempTable) {
            if (! x.getQuantityImport().getText().isEmpty()) {
                x.setTotalPriceImport();
                addPurchaseTable.setItems(tempTable);
                addPurchaseTable.refresh();
                total += x.getTotalPriceImport();
            }
        }
        totalPricePurchase.setText(String.valueOf(total));
    }


    public void removePurchase(ActionEvent event) {
        int selectedId = addPurchaseTable.getSelectionModel().getSelectedIndex();
        addPurchaseTable.getItems().remove(selectedId);
        ObservableList<ImportProduct> tempTable = addPurchaseTable.getItems();
        Long total = 0L;
        for (ImportProduct x : tempTable) {
            if (! x.getQuantityImport().getText().isEmpty()) {
                x.setTotalPriceImport();
                addPurchaseTable.setItems(tempTable);
                addPurchaseTable.refresh();
                total += x.getTotalPriceImport();
            }
        }
        totalPricePurchase.setText(String.valueOf(total));
    }

    public void selectProductToPurchase(MouseEvent mouseEvent) {
        int flag = 0;
        Product product = purchaseTableView.getSelectionModel().getSelectedItem();
        ImportProduct importProduct = new ImportProduct();
        importProduct.setProductName(product.getProductName());
        importProduct.setProductID(product.getProductID());
        importProduct.setImportPrice(product.getImportPrice());
        importProduct.setQuantityImport(new TextField("1"));
        importProduct.setCategory(product.getCategory());
        importProduct.setTotalPriceImport();

        for (ImportProduct x : importProductObservableList) {
            if (x.getProductName().equals(importProduct.getProductName())) {
                flag = 1;
            }
        }

        if (flag == 0) {
            importProductObservableList.add(importProduct);
        }
    }

    public void selectProductToOrder(MouseEvent mouseEvent) {
        int flag = 0;
        Product product = productOrderTableView.getSelectionModel().getSelectedItem();
        OrderProduct orderProduct = new OrderProduct();
        orderProduct.setProductName(product.getProductName());
        orderProduct.setProductID(product.getProductID());
        orderProduct.setImportPrice(product.getImportPrice());
        orderProduct.setSellPrice(product.getSellPrice());
        orderProduct.setOrderQuantity(new TextField("1"));
        orderProduct.setCategory(product.getCategory());
        orderProduct.setTotalPriceOrder();
        for (OrderProduct x : orderProductObservableList) {
            if (x.getProductName().equals(orderProduct.getProductName())) {
                flag = 1;
            }
        }

        if (flag == 0) {
            orderProductObservableList.add(orderProduct);
        }
    }

    public void saveChangeTbOrder(ActionEvent event) {
        ObservableList<OrderProduct> tempTable = orderTableView.getItems();
        Long total = 0L;
        for (OrderProduct x : tempTable) {
            if (! x.getOrderQuantity().getText().isEmpty()) {
                if (Integer.parseInt(x.getOrderQuantity().getText()) > x.getQuantity()) {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("ERROR!!!!");
                    alert.setContentText("check ");
                    alert.setHeaderText(null);
                    alert.show();
                }
                x.setTotalPriceOrder();
                orderTableView.setItems(tempTable);
                orderTableView.refresh();
                total += x.getTotalPriceOrder();
            }
        }
        orderTotalPrice.setText(String.valueOf(total));
    }

    public void removeOrder(ActionEvent event) {
        int selectedId = orderTableView.getSelectionModel().getSelectedIndex();
        orderTableView.getItems().remove(selectedId);
        ObservableList<OrderProduct> tempTable = orderTableView.getItems();
        Long total = 0L;
        for (OrderProduct x : tempTable) {
            if (! x.getOrderQuantity().getText().isEmpty()) {
                x.setTotalPriceOrder();
                orderTableView.setItems(tempTable);
                orderTableView.refresh();
                total += x.getTotalPriceOrder();
            }
        }
        orderTotalPrice.setText(String.valueOf(total));
    }

    public void addOrder() {
        dashboardModel = new DashboardModel();
        if (orderProductObservableList.isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("ERROR!!!!");
            alert.setContentText("check your order table again");
            alert.setHeaderText(null);
            alert.show();
        } else {
            if (dashboardModel.checkCustomer(orderCustomerName.getText(), orderEmail.getText(), orderPhoneNumber.getText())) {

            } else {

            }
        }
    }
}
