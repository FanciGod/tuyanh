package entity;

import java.sql.Date;

public class Bill {
    private int billId;
    private String customer;
    private String createBy;
    private java.sql.Date createTime;
    private long totalPrice;

    public Bill(int billId, String customer, String createBy, long totalPrice) {
        this.billId = billId;
        this.customer = customer;
        this.createBy = createBy;
        this.totalPrice = totalPrice;
    }

    public Bill(int billId, String customer, String createBy, Date createTime, long totalPrice) {
        this.billId = billId;
        this.customer = customer;
        this.createBy = createBy;
        this.createTime = createTime;
        this.totalPrice = totalPrice;
    }

    public Bill() {
    }

    public int getBillId() {
        return billId;
    }

    public void setBillId(int billId) {
        this.billId = billId;
    }

    public String getCustomer() {
        return customer;
    }

    public void setCustomer(String customer) {
        this.customer = customer;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy;
    }

    public long getTotalPrice() {
        return totalPrice;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public void setTotalPrice(long totalPrice) {
        this.totalPrice = totalPrice;
    }
}
