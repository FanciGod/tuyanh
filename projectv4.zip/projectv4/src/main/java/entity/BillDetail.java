package entity;

public class BillDetail {
    private int billDetailId;
    private int billId;
    private String productName;
    private int quantity;

    public BillDetail(int billDetailId, int billId, String productName, int quantity) {
        this.billDetailId = billDetailId;
        this.billId = billId;
        this.productName = productName;
        this.quantity = quantity;
    }

    public int getBillDetailId() {
        return billDetailId;
    }

    public void setBillDetailId(int billDetailId) {
        this.billDetailId = billDetailId;
    }

    public int getBillId() {
        return billId;
    }

    public void setBillId(int billId) {
        this.billId = billId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}
