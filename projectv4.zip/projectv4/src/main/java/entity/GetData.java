package entity;

public class GetData {
    public static int userId;
    public static String name;
    public static int getProductID;
    public static int getCustomerID;
    public static int getSupplierID;

    public static String username;
    public static String password;
    public static String path;
}
