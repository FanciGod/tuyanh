package entity;

import javafx.scene.control.TextField;

public class ImportProduct extends Product{
    protected TextField quantityImport;

    protected long totalPriceImport;

    public ImportProduct() {
    }

    public ImportProduct(int productID, String productName, long sellPrice, long importPrice, int quantity, String category, String supplierName, String image, TextField quantityImport, long totalPriceImport) {
        super(productID, productName, sellPrice, importPrice, quantity, category, supplierName, image);
        this.quantityImport = quantityImport;
        this.totalPriceImport = (long) (Double.parseDouble(this.quantityImport.getText()) * super.getImportPrice());
    }

    public TextField getQuantityImport() {
        return quantityImport;
    }

    public void setQuantityImport(TextField quantityImport) {
        this.quantityImport = quantityImport;
    }

    public long getTotalPriceImport() {
        return totalPriceImport;
    }

    public void setTotalPriceImport() {
        this.totalPriceImport = (long) (Double.parseDouble(this.quantityImport.getText()) * super.getImportPrice()) ;
    }
}