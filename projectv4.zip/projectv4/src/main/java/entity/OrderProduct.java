package entity;

import javafx.scene.control.TextField;

public class OrderProduct extends Product {
    private TextField orderQuantity;
    private long totalPriceOrder;

    public OrderProduct() {
    }

    public OrderProduct(int productID, String productName, long sellPrice, long importPrice, int quantity, String category, String supplierName, String image, TextField orderQuantity, long totalPriceOrder) {
        super(productID, productName, sellPrice, importPrice, quantity, category, supplierName, image);
        this.orderQuantity = orderQuantity;
        this.totalPriceOrder = (long) (Double.parseDouble(this.orderQuantity.getText()) * super.getSellPrice());
    }

    public TextField getOrderQuantity() {
        return orderQuantity;
    }

    public void setOrderQuantity(TextField orderQuantity) {
        this.orderQuantity = orderQuantity;
    }

    public long getTotalPriceOrder() {
        return totalPriceOrder;
    }

    public void setTotalPriceOrder() {
        this.totalPriceOrder = (long) (Double.parseDouble(this.orderQuantity.getText()) * super.getSellPrice()) ;
    }
}
