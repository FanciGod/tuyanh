package entity;

import java.sql.Date;

public class Purchase {
    private int purchaseId;
    private String supplierName;
    private String accountName;
    private java.sql.Date createTime;
    private long totalPrice;

    public Purchase() {
    }

    public Purchase(int purchaseId, String supplierName, String accountName, Date createTime, long totalPrice) {
        this.purchaseId = purchaseId;
        this.supplierName = supplierName;
        this.accountName = accountName;
        this.createTime = createTime;
        this.totalPrice = totalPrice;
    }

    public int getPurchaseId() {
        return purchaseId;
    }

    public void setPurchaseId(int purchaseId) {
        this.purchaseId = purchaseId;
    }

    public String getSupplierName() {
        return supplierName;
    }

    public void setSupplierName(String supplierName) {
        this.supplierName = supplierName;
    }

    public String getAccountName() {
        return accountName;
    }

    public void setAccountName(String accountName) {
        this.accountName = accountName;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public long getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(long totalPrice) {
        this.totalPrice = totalPrice;
    }
}
