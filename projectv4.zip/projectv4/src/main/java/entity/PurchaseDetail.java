package entity;

public class PurchaseDetail {
    private int purcharDetailId;
    private int purchaseId;
    private String productName;
    private int quantity;

    public PurchaseDetail() {
    }

    public PurchaseDetail(int purcharDetailId, int purchaseId, String productName, int quantity) {
        this.purcharDetailId = purcharDetailId;
        this.purchaseId = purchaseId;
        this.productName = productName;
        this.quantity = quantity;
    }

    public int getPurcharDetailId() {
        return purcharDetailId;
    }

    public void setPurcharDetailId(int purcharDetailId) {
        this.purcharDetailId = purcharDetailId;
    }

    public int getPurchaseId() {
        return purchaseId;
    }

    public void setPurchaseId(int purchaseId) {
        this.purchaseId = purchaseId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}
